var array = [], helperArray = [], tempTitle;

$(document).ready(function(){
	startInitialization();
	$('.form__button').click(function(){
	    let temp = document.getElementsByTagName('li');
	    let parentOperationCategoryId, operationCategoryType, activityType, title, id = "", url = '/putItem/';
	    $(temp).each(function(){
	        if($($(this).find('.articles__name')[0]).text() == tempTitle){
	            id = $(this).attr('name');
	            url = '/changeItem/';
	        }
	        if($($(this).find('.articles__name')[0]).text() == $('select').val()){
	            parentOperationCategoryId = $(this).attr('name');
	            operationCategoryType = $(this).attr('data-operationCategoryType');
	            activityType = $(this).attr('data-activityType');
	            title = $('input').val();
	        }
	    });
	    $.ajax({
        url: url,
        method: 'POST',
        data:{title: title, parentOperationCategoryId: parentOperationCategoryId, operationCategoryType: operationCategoryType, activityType: activityType,id: id},
        success: function(list) {
            if(list.isSuccess == false)
                alert('Ошибка операции');
            $('.main__form').addClass('pass');
            getList();
            }
        });
	});
	$('.root-articles__item').click(function(){
		$('.root-articles__item').each(function(){
			$(this).removeClass('active');
		});
		$(this).addClass('active');
		getList();
	});
	$('.operationcategories__create').click(function(){
	    tempTitle = "";
		$('.main__form').removeClass('pass');
		$('h2').text('Создание учетной статьи - ' + $('.root-articles__item.active').text() + '');
		$('.main__form  input').val("Название");
		$('.form__button').text("Создать");
		let temp = document.getElementsByTagName('li');
		let item;
		$('select').empty();
		$(temp).each(function(){
		    item = $($(this).find('.articles__name')[0]).text();
		    $('select').append('<option value="'+ item +'">'+ item +'</option>');
		});
	});
	$(document).on('click touchstart','.articles__pen', function(){
		$('.main__form').removeClass('pass');
		$('h2').text('Редактирование учетной статьи - ' + $('.root-articles__item.active').text() + '');
		$('.main__form  input').val("" + $($(this).parent().parent().find('.articles__name')[0]).text());
		tempTitle = $($(this).parent().parent().find('.articles__name')[0]).text();
		$('.form__button').text("Сохранить");
		let temp = document.getElementsByTagName('li');
		let item, buff = $(this).parent().parent().parent().attr("data-idParent");
		$('select').empty();
		$(temp).each(function(){
		    item = $($(this).find('.articles__name')[0]).text();
		    $('select').append('<option value="'+ item +'">'+ item +'</option>');
		    if ($(this).attr('name') == "" + buff)
		        $('select').val("" + item);
		});
	});
	$(document).on('click touchstart','.articles__cross', function(){
		let id = $(this).parent().parent().parent().attr('name');
		$.ajax({
        url: '/deleteItem/',
        method: 'POST',
        data:{id: id},
        success: function(list) {
            if(list.isSuccess == false)
                alert('Ошибка операции');
            getList();
            }
        });
	});
	$('.form__cross').click(function(){
		$('.main__form').addClass('pass');
	});
	$('.cancel').click(function(){
		$('.main__form').addClass('pass');
	});
	$('button').click(function(){
		$('.main__form').addClass('pass');
	});
});


function startInitialization(){
	$('.root-articles__item').each(function(index){
	    if(index == 0){
	        $(this).addClass('active');
			getList();
	    }
	});
}
function getList(){
    $('.articles__list').empty();
    $.ajax({
        url: '/getList/',
        method: 'POST',
        success: function(list) {
            array = list.items;
            helperArray[0] = $('.root-articles__item.active').attr('data-id');
            console.log(helperArray[0]);
            buildTree(1);
        }
    });
}
function buildTree(tab){
    let temp = helperArray, count = 0;
    helperArray = [];
    temp.forEach(function(helperItem) {
        array.forEach(function(item) {
            if(item.parentOperationCategoryId == helperItem){
                helperArray[count] = item.operationCategoryId;
                drawRoot(item.title,item.activityType,item.operationCategoryType, item.parentOperationCategoryId, item.operationCategoryId, tab);
                count++;
            }
        });
    });
    if(helperArray.length == 0) return;
    else buildTree(tab + 1);
}
function drawRoot(name,activityType, operationCategoryType, idParent, idChild, tab){
    let el;
    if(tab == 1){
       el = document.getElementsByClassName("articles__list")[0];
    }
    else{
        el = $(document.getElementsByName("" + idParent)[0]).find('.articles__list')[0];
    }
    $(el).css('margin-left',Number(tab*10) + 'px').append(
        '<li class="articles__link" data-idParent="' + idParent + '" data-operationCategoryType="' + operationCategoryType + '" data-activityType="' + activityType + '" name="' + idChild + '">'+
            '<div class="articles__body">'+
                '<div class="articles__info">'+
                    '<div class="articles__name">' + name + '</div>'+
                '</div>'+
                '<div class="articles__modify">'+
                    '<svg xmlns="http://www.w3.org/2000/svg" class="articles__pen">'+
                        '<path fill="currentColor" fill-rule="evenodd" d="M3.556 13.586l.891-.891-2.302-2.302-.891.891v2.302h2.302zm6.633-6.614l-4.826 4.826L3.06 9.496 7.887 4.67l2.302 2.302zM8.15 2.615l4.076 4.075-8.15 8.15H0v-4.075l8.15-8.15zm6.691.94c0 .334-.137.657-.362.882l-1.626 1.626-4.075-4.075L10.403.372A1.23 1.23 0 0111.284 0c.333 0 .657.137.892.372l2.302 2.292c.225.235.362.559.362.892z">'+
                        '</path>'+
                    '</svg>'+
                    '<svg xmlns="http://www.w3.org/2000/svg" class="articles__cross">'+
                        '<path fill="currentColor" d="M14 1.41L12.59 0 7 5.59 1.41 0 0 1.41 5.59 7 0 12.59 1.41 14 7 8.41 12.59 14 14 12.59 8.41 7 14 1.41z">'+
                        '</path>'+
                    '</svg>'+
                '</div>'+
            '</div>'+
            '<ul class="articles__list"></ul>'+
        '</li>'
    )
}