from django.http import JsonResponse
from django.shortcuts import render
import requests
import json
from django.views.decorators.csrf import csrf_exempt

url = "https://api.planfact.io/api/v1/operationcategories"
headers = {'Content-Type': 'application/json',
               'X-ApiKey': 'x4PhQR_z7PV5t0qnLUXVD7kxmWhAlScNQcOMg_uIENGDbhdHwYzT5aN6-7aIWB_pAA_5ja2B1Hr3oOq1FxTkHPUImavnYtkdGBybFUWnRErfbvl_rIkXQZqEQfC-LwzaN5i1cT9eO0KyooqqWO79OhY1Vx3YO7y_4x58VgSTe4USzx7bkd25GE2YpcOn4S2h7cU-ADXdwI5sVjbMHHBORhcyo0C59ar1cwuph43I3OCsFT2rsTF38_w9qX8n376-du_U6HzE7M4YIqwyGUh9btognzLVSeCBFa6g4ndsR2wyWq6tsNrQAB2nXcZ_rzYK6yezT_fIeCgaT9yhaCkJH5NUAhvAnIQaTA23_e5514Drlzg4yySApEHpNcUVjpor4Gam_IH-j_wyHTxfpdHGzS13jSo1ZLOfalIiilMO07Dr9dXwWu5ISk6ea8ZZta_GDnwwoFfyIW6eroogE7d8RKhrOJUPvZWv4oBGnJPLU-YgY765MOMvNW9S2Qt6uJYn8sQoDw'}

def Request(data, title, id):
    link = url + id
    if(title == "GET" or title == "DELETE"):
        payload = ""
    else:
        payload = json.dumps({
            "operationCategoryType": data['operationCategoryType'],
            "activityType": data['activityType'],
            "parentOperationCategoryId": data['parentOperationCategoryId'],
            "title": data['title']
        })

    response = requests.request(title, link, headers=headers, data=payload)
    items = response.json()
    return items


def startPage(request):
    items = Request("", "GET", "")
    return render(request, 'index.html', items['data'])

@csrf_exempt
def getList(request):
    if request.method == "POST":
        items = Request("", "GET", "")
        return JsonResponse(items['data'])
@csrf_exempt
def putItem(request):
    if request.method == "POST":
        data = request.POST
        response = Request(data, "POST", "")
        return JsonResponse(response)
@csrf_exempt
def changeItem(request):
    if request.method == "POST":
        data = request.POST
        response = Request(data, "PUT", "/" + data['id'])
        return JsonResponse(response)
@csrf_exempt
def deleteItem(request):
    if request.method == "POST":
        data = request.POST
        response = Request("", "DELETE", "/" + data['id'])
        return JsonResponse(response)